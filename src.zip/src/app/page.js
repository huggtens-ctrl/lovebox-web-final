"use client";
import { useState } from "react";
import { supabase } from "@/lib/supabase"; // Gọi ống hút Supabase ra

export default function LoginScreen() {
  const [activeTab, setActiveTab] = useState("login"); // 'login' hoặc 'register'
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  // Hàm xử lý Đăng nhập
  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    
    if (error) {
      alert("❌ Lỗi: Sai tài khoản hoặc mật khẩu!");
    } else {
     alert("✅ ĐĂNG NHẬP THÀNH CÔNG!");
      window.location.href = "/dashboard";
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#EAF7EA] p-4">
      <div className="w-full max-w-md">
        {/* Tiêu đề */}
        <div className="mb-8 text-center md:text-left">
          <h1 className="text-3xl font-bold text-[#2D6A4F] mb-2">🏨 LOVEBOX BILL CLOUD</h1>
          <p className="text-[#5A7C68] text-lg">Đăng nhập bằng Email để vào ca</p>
        </div>

        {/* Khung thẻ chính */}
        <div className="bg-white rounded-2xl shadow-xl border border-[#B7E4C7] overflow-hidden">
          {/* 2 Nút Tab (Đăng nhập / Đăng ký) */}
          <div className="flex border-b border-[#B7E4C7]">
            <button
              onClick={() => setActiveTab("login")}
              className={`flex-1 py-4 text-base font-bold transition-colors ${
                activeTab === "login" ? "bg-[#2D6A4F] text-white" : "text-[#5A7C68] hover:bg-[#F4FFF7]"
              }`}
            >
              Đăng nhập
            </button>
            <button
              onClick={() => setActiveTab("register")}
              className={`flex-1 py-4 text-base font-bold transition-colors ${
                activeTab === "register" ? "bg-[#2D6A4F] text-white" : "text-[#5A7C68] hover:bg-[#F4FFF7]"
              }`}
            >
              Tạo tài khoản
            </button>
          </div>

          {/* Form Nhập liệu */}
          <form onSubmit={handleLogin} className="p-6 md:p-8">
            <div className="mb-5">
              <label className="block text-[#18392B] text-base font-semibold mb-2">Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#52B788] focus:border-transparent transition-all"
                placeholder="Ví dụ: quanly@gmail.com"
              />
            </div>

            <div className="mb-6">
              <label className="block text-[#18392B] text-base font-semibold mb-2">Mật khẩu</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#52B788] focus:border-transparent transition-all"
                placeholder="••••••••"
              />
            </div>

            {/* Nút Quên mật khẩu & Ghi nhớ */}
            {activeTab === "login" && (
              <div className="flex items-center justify-between mb-8">
                <label className="flex items-center text-[#18392B] cursor-pointer">
                  <input type="checkbox" className="w-4 h-4 text-[#2D6A4F] rounded border-gray-300 focus:ring-[#2D6A4F]" />
                  <span className="ml-2">Nhớ mật khẩu</span>
                </label>
                <a href="#" className="text-[#EF4444] text-sm hover:underline font-medium">
                  Quên mật khẩu?
                </a>
              </div>
            )}

            {/* Nút Xác nhận lớn */}
            <button
              type="submit"
              disabled={loading}
              className={`w-full py-4 rounded-xl text-white font-bold text-lg transition-transform active:scale-95 ${
                activeTab === "login"
                  ? "bg-[#2D6A4F] hover:bg-[#18392B]"
                  : "bg-[#F59E0B] hover:bg-[#D97706]"
              } ${loading ? "opacity-70 cursor-not-allowed" : ""}`}
            >
              {loading ? "⏳ Đang xử lý..." : activeTab === "login" ? "✅ Đăng nhập" : "📝 Tạo tài khoản"}
            </button>
          </form>
        </div>

        {/* Chữ ký bản quyền */}
        <div className="mt-8 text-center text-[#5A7C68] text-sm font-semibold italic">
          ✨ Created by ViecGiKhoCoHungLo ✨ ver Web
        </div>
      </div>
    </div>
  );
}