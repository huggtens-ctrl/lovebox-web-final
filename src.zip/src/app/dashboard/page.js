"use client";
import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";
import { money, overdueText, fmtDt } from "@/lib/utils";
import RoomModal from "@/components/RoomModal";

export default function DashboardScreen() {
  // Dữ liệu quản lý nhánh (Tạm gán Q1, sau này sẽ lấy từ lúc Đăng nhập)
  const currentBranchId = "TEST SEVER"; 
  const [recentInvoices, setRecentInvoices] = useState([]);
  const [searchBill, setSearchBill] = useState("");

  // Các hộp chứa dữ liệu thật
  const [groups, setGroups] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [summary, setSummary] = useState({ total: 0, cash: 0, transfer: 0, busy: 0, overdue: 0 });
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedRoomAction, setSelectedRoomAction] = useState(null); // Quản lý popup

  // 🚀 ĐỘNG CƠ BÚA TẠ: Tải dữ liệu và tự động lắng nghe
  useEffect(() => {
    fetchDashboardData();

    // Lắp radar Realtime: Quét sự thay đổi của bảng 'rooms' và 'orders'
    const roomListener = supabase
      .channel('rooms-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'rooms' }, () => {
        fetchDashboardData(); // Có người đổi trạng thái phòng -> Tự động load lại
      })
      .subscribe();

    const orderListener = supabase
      .channel('orders-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, () => {
        fetchDashboardData(); // Có bill mới -> Tự động load lại
      })
      .subscribe();

    // Dọn dẹp radar khi tắt trình duyệt
    return () => {
      supabase.removeChannel(roomListener);
      supabase.removeChannel(orderListener);
    };
  }, []);

  // Hàm "Đi đêm" với Supabase để rút dữ liệu
  const fetchDashboardData = async () => {
    try {
      // 1. Lấy danh sách nhóm phòng
      const { data: typesData } = await supabase.from('room_types').select('*').eq('branch_id', currentBranchId).order('name');
      setGroups(typesData || []);

      // 2. Lấy danh sách phòng
      const { data: roomsData } = await supabase.from('rooms').select('*').eq('branch_id', currentBranchId).order('name');
      
      // 3. Lấy các hóa đơn đang thuê
      // Lấy 20 hóa đơn gần nhất cho Cột 3
      const { data: recentData } = await supabase.from('orders')
        .select('*, rooms(name)')
        .eq('branch_id', currentBranchId)
        .order('id', { ascending: false })
        .limit(20);
      setRecentInvoices(recentData || []);
      const { data: activeOrders } = await supabase.from('orders').select('*').eq('branch_id', currentBranchId).eq('status', 'ĐANG THUÊ');

      // 4. Lắp ráp dữ liệu (Giống hệt vòng lặp của sếp trong hàm _bg_fetch_and_render)
      let busyCount = 0;
      let overdueCount = 0;

      const mappedRooms = (roomsData || []).map(room => {
        // Tìm Nhóm phòng
        const typeObj = (typesData || []).find(t => t.id === room.room_type_id);
        const typeName = typeObj ? typeObj.name : "Chưa phân loại";

        // Tìm Hóa đơn đang chạy của phòng này
        const order = (activeOrders || []).find(o => o.room_id === room.id);
        
        let isOverdue = false;
        let customer = "";
        let timeStr = "";
        let total = 0;

        if (order) {
          busyCount++;
          customer = order.customer_name || "Khách lẻ";
          timeStr = `${fmtDt(order.checkin_time)} → ${fmtDt(order.expected_checkout_time)}`;
          
          // Tính tiền tạm (Chưa cộng dịch vụ ăn uống, phần ăn uống tính sau ở Giai đoạn 4)
          const roomMoney = parseInt(order.combo_price || 0) + parseInt(order.extra_money || 0);
          const adjMoney = parseInt(order.adjustment_money || 0);
          total = Math.max(0, roomMoney + adjMoney);

          // Check quá giờ
          const overTxt = overdueText(order.expected_checkout_time);
          if (overTxt) {
            isOverdue = true;
            overdueCount++;
          }
        }

        return {
          ...room,
          type_name: typeName,
          isOverdue,
          customer,
          timeStr,
          total,
          activeOrder: order
        };
      });

      setRooms(mappedRooms);

      // Cập nhật thẻ Tóm tắt (Tiền mặt/CK sẽ được nối thêm khi làm tới Sổ quỹ)
      setSummary({ total: 0, cash: 0, transfer: 0, busy: busyCount, overdue: overdueCount });
      setLoading(false);

    } catch (error) {
      console.error("Lỗi rút dữ liệu Supabase:", error);
    }
  };

  // Hàm tô màu giống Python
  const getStatusColor = (status, isOverdue) => {
    if (status === "ĐANG THUÊ") return isOverdue ? "bg-[#FEE2E2] border-[#EF4444]" : "bg-[#FFE7E7] border-[#EF4444]";
    if (status === "DỌN PHÒNG") return "bg-[#FFF5CC] border-[#F59E0B]";
    return "bg-[#E7FBEF] border-[#2D6A4F]"; 
  };
  const getStatusText = (status, isOverdue) => {
    if (status === "ĐANG THUÊ") return isOverdue ? "text-[#EF4444]" : "text-[#EF4444]";
    if (status === "DỌN PHÒNG") return "text-[#F59E0B]";
    return "text-[#2D6A4F]";
  };

  // Lọc phòng theo Nhóm đang chọn
  const displayRooms = selectedGroup 
    ? rooms.filter(r => r.room_type_id === selectedGroup) 
    : rooms;

  return (
    <div className="flex flex-col h-full space-y-4">
      {/* 1. THẺ TÓM TẮT */}
      <div className="grid grid-cols-5 gap-4">
        {[
          { title: "Tổng doanh thu ròng", icon: "💰", val: money(summary.total) },
          { title: "Tiền mặt", icon: "💵", val: money(summary.cash) },
          { title: "Chuyển khoản", icon: "🏦", val: money(summary.transfer) },
          { title: "Đang thuê", icon: "🛏️", val: summary.busy },
          { title: "Quá giờ", icon: "⏰", val: summary.overdue }
        ].map((item, idx) => (
          <div key={idx} className="bg-white p-4 rounded-2xl border border-[#B7E4C7] shadow-sm flex flex-col justify-center">
            <p className="text-[#5A7C68] text-sm font-medium mb-1">{item.icon} {item.title}</p>
            <p className="text-[#2D6A4F] text-2xl font-bold">{item.val}</p>
          </div>
        ))}
      </div>

      {/* 2. KHU VỰC CHÍNH */}
      <div className="flex-1 grid grid-cols-12 gap-4 overflow-hidden">
        
        {/* CỘT 1: NHÓM PHÒNG */}
        <div className="col-span-2 bg-white rounded-2xl border border-[#B7E4C7] flex flex-col overflow-hidden">
          <h2 className="text-lg font-bold text-[#2D6A4F] p-4 pb-2">🏷️ Nhóm phòng</h2>
          <div className="flex-1 overflow-y-auto p-3 space-y-2 custom-scrollbar bg-[#F7FFF9]">
            <button 
              onClick={() => setSelectedGroup(null)}
              className={`w-full text-left px-4 py-3 rounded-xl font-bold border transition-colors ${!selectedGroup ? "bg-[#52B788] text-white border-[#52B788]" : "bg-white text-[#18392B] border-[#B7E4C7] hover:bg-[#EAF7EA]"}`}
            >
              🏨 Tất cả phòng
            </button>
            {groups.map(g => (
              <button 
                key={g.id} 
                onClick={() => setSelectedGroup(g.id)}
                className={`w-full text-left px-4 py-3 rounded-xl font-medium border transition-colors ${selectedGroup === g.id ? "bg-[#52B788] text-white border-[#52B788] font-bold" : "bg-white text-[#18392B] border-[#B7E4C7] hover:bg-[#EAF7EA]"}`}
              >
                🏷️ {g.name}
              </button>
            ))}
          </div>
        </div>

        {/* CỘT 2: SƠ ĐỒ PHÒNG */}
        <div className="col-span-7 bg-white rounded-2xl border border-[#B7E4C7] flex flex-col overflow-hidden">
          <h2 className="text-lg font-bold text-[#2D6A4F] p-4 pb-2">
            🏠 Sơ đồ phòng {loading && <span className="text-sm font-normal text-yellow-600 animate-pulse">⏳ Đang tải...</span>}
          </h2>
          <div className="flex-1 overflow-y-auto p-4 bg-[#F7FFF9] custom-scrollbar">
            <div className="grid grid-cols-3 gap-4">
              {displayRooms.map(room => (
                <div key={room.id} className={`p-4 rounded-2xl border ${getStatusColor(room.status, room.isOverdue)} shadow-sm flex flex-col justify-between h-48`}>
                  <div>
                    <h3 className="text-xl font-bold text-[#18392B]">
                      {room.status === "ĐANG THUÊ" ? "🔴" : room.status === "DỌN PHÒNG" ? "🧹" : "🟢"} {room.name}
                    </h3>
                    <p className="text-sm text-[#5A7C68]">{room.type_name}</p>
                    <p className={`text-base font-bold mt-1 ${getStatusText(room.status, room.isOverdue)}`}>
                      {room.isOverdue ? "QUÁ GIỜ" : room.status}
                    </p>
                    {room.status === "ĐANG THUÊ" && (
                      <div className="mt-2 text-sm text-[#18392B] leading-tight">
                        <p className="truncate">👤 {room.customer}</p>
                        <p>🕒 {room.timeStr}</p>
                        <p className="font-bold mt-1">💰 {money(room.total)}</p>
                      </div>
                    )}
                  </div>
                  <button 
  onClick={() => setSelectedRoomAction(room)} 
  className="mt-3 w-full py-2 bg-[#2D6A4F] hover:bg-[#52B788] text-white rounded-xl font-bold transition-colors"
>
                    ⚙️ Thao tác
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* CỘT 3: HÓA ĐƠN MỚI */}
        <div className="col-span-3 bg-white rounded-2xl border border-[#B7E4C7] flex flex-col overflow-hidden">
          <h2 className="text-lg font-bold text-[#2D6A4F] p-4 pb-2">🧾 Hóa đơn mới</h2>
          
          <div className="px-4 pb-2 flex space-x-2">
            <input type="text" value={searchBill} onChange={(e) => setSearchBill(e.target.value)} placeholder="Nhập mã HĐ..." className="flex-1 px-3 py-2 border rounded-xl outline-none focus:ring-2 focus:ring-[#52B788]" />
          </div>

          <div className="flex-1 overflow-y-auto p-4 bg-[#F7FFF9] custom-scrollbar space-y-3">
            {recentInvoices.filter(x => x.id.toString().includes(searchBill)).map(inv => (
              <div key={inv.id} className="bg-white p-3 rounded-xl border border-[#B7E4C7] shadow-sm">
                <p className="font-bold text-[#18392B]">🧾 #{inv.id} - {inv.rooms?.name}</p>
                <p className="text-sm text-[#5A7C68] my-1">👤 {inv.customer_name || 'Khách lẻ'}<br/>💰 {money(inv.total_money)} | {inv.payment_method || inv.status}</p>
                
                {inv.status === 'ĐÃ THANH TOÁN' && (
                  <button onClick={async () => {
                    if (!window.confirm("Khôi phục hóa đơn này về trạng thái ĐANG THUÊ?")) return;
                    const { data: checkRoom } = await supabase.from('orders').select('id').eq('room_id', inv.room_id).eq('status', 'ĐANG THUÊ');
                    if (checkRoom && checkRoom.length > 0) return alert("Phòng này đang có khách mới, không thể khôi phục đè lên được!");
                    
                    setLoading(true);
                    await supabase.from('orders').update({ status: 'ĐANG THUÊ', checkout_time: null, paid_at: null, payment_method: '', cash_amount: 0, transfer_amount: 0, total_money: 0, discount: 0 }).eq('id', inv.id);
                    await supabase.from('rooms').update({ status: 'ĐANG THUÊ' }).eq('id', inv.room_id);
                    setLoading(false);
                  }} className="mt-2 w-full py-1.5 bg-[#F59E0B] hover:bg-[#D97706] text-white font-bold rounded-lg text-sm transition-colors">
                    🔄 Khôi phục
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* 3. POPUP THAO TÁC PHÒNG */}
      <RoomModal 
        isOpen={!!selectedRoomAction} 
        room={selectedRoomAction} 
        onClose={() => setSelectedRoomAction(null)} 
      />
    </div>
  );
}