"use client";
import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";

export default function RoomsManager() {
  const currentBranchId = "Q1";
  const [rooms, setRooms] = useState([]);
  const [groups, setGroups] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [bulkText, setBulkText] = useState("Phòng 101\nPhòng 102\nPhòng 201\nPhòng 202");
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    setLoading(true);
    // Kéo danh sách nhóm phòng
    const { data: gData } = await supabase.from('room_types').select('*').eq('branch_id', currentBranchId).order('name');
    setGroups(gData || []);
    if (gData && gData.length > 0) setSelectedGroup(gData[0].id);

    // Kéo danh sách phòng
    const { data: rData } = await supabase.from('rooms').select('*, room_types(name)').eq('branch_id', currentBranchId).order('name');
    setRooms(rData || []);
    setLoading(false);
  };

  const handleBulkAdd = async () => {
    if (!selectedGroup) return alert("Vui lòng tạo và chọn Nhóm phòng trước!");
    const lines = bulkText.split('\n').map(l => l.trim()).filter(l => l);
    if (lines.length === 0) return alert("Vui lòng nhập tên phòng!");

    setLoading(true);
    let count = 0;
    for (const name of lines) {
      if (name.startsWith("Phòng 101") && bulkText.includes("Phòng 102")) {
        // Bỏ qua nếu sếp để nguyên text mẫu
        continue;
      }
      const { error } = await supabase.from('rooms').insert([{
        name, room_type_id: selectedGroup, status: 'TRỐNG', branch_id: currentBranchId
      }]);
      if (!error) count++;
    }
    
    if (count > 0) {
      alert(`✅ Đã xây xong ${count} phòng mới vào chi nhánh!`);
      setBulkText("");
      fetchData();
    } else {
      alert("❌ Chưa thêm được phòng nào. Sếp xóa text mẫu đi và nhập tên phòng thật nhé!");
    }
    setLoading(false);
  };

  const handleDelete = async (id, name, status) => {
    if (status === 'ĐANG THUÊ') return alert("❌ Phòng đang có khách, không thể xóa!");
    if (!window.confirm(`Sếp có chắc chắn muốn XÓA vĩnh viễn [${name}] không?`)) return;
    
    setLoading(true);
    await supabase.from('rooms').delete().eq('id', id);
    fetchData();
  };

  return (
    <div className="flex flex-col h-full space-y-4">
      <div className="bg-white p-6 rounded-2xl border border-[#B7E4C7]">
        <h2 className="text-2xl font-bold text-[#2D6A4F]">🚪 QUẢN LÝ SƠ ĐỒ PHÒNG</h2>
        <p className="text-[#5A7C68]">Thêm phòng hàng loạt siêu tốc hoặc xóa các phòng không sử dụng.</p>
      </div>

      <div className="flex-1 grid grid-cols-12 gap-6 overflow-hidden">
        
        {/* CỘT TRÁI: THÊM HÀNG LOẠT */}
        <div className="col-span-4 bg-white p-6 rounded-2xl border border-[#B7E4C7] h-fit shadow-sm">
          <h3 className="text-lg font-bold text-[#18392B] mb-4">🚀 Thêm Phòng Hàng Loạt</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">1. Chọn Nhóm Phòng</label>
              <select value={selectedGroup} onChange={(e) => setSelectedGroup(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-gray-300 font-medium outline-none">
                {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">2. Nhập tên phòng (Mỗi phòng 1 dòng)</label>
              <textarea value={bulkText} onChange={(e) => setBulkText(e.target.value)} rows={8} className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-[#52B788] outline-none resize-none" />
            </div>
            <button onClick={handleBulkAdd} disabled={loading} className="w-full py-3 bg-[#F57C00] hover:bg-[#E65100] text-white font-bold rounded-xl transition-colors mt-2 shadow-md">
              {loading ? "⏳ Đang xây phòng..." : "💾 XÂY TẤT CẢ CÁC PHÒNG NÀY"}
            </button>
          </div>
        </div>

        {/* CỘT PHẢI: DANH SÁCH PHÒNG HIỆN TẠI */}
        <div className="col-span-8 bg-white rounded-2xl border border-[#B7E4C7] flex flex-col overflow-hidden shadow-sm">
          <h3 className="text-lg font-bold text-[#18392B] p-6 pb-2 border-b border-[#EAF7EA]">📋 Sơ đồ hiện tại {loading && "⏳"}</h3>
          <div className="flex-1 overflow-y-auto p-6 bg-[#F7FFF9] custom-scrollbar">
            <div className="grid grid-cols-2 gap-4">
              {rooms.map(r => (
                <div key={r.id} className="bg-white p-4 rounded-xl border border-[#B7E4C7] flex justify-between items-center shadow-sm">
                  <div>
                    <p className="font-bold text-[#18392B] text-lg">🏠 {r.name}</p>
                    <p className="text-sm text-[#5A7C68] mt-1">{r.room_types?.name || 'Chưa phân loại'}</p>
                    <p className={`text-xs font-bold mt-1 ${r.status === 'ĐANG THUÊ' ? 'text-red-600' : 'text-green-600'}`}>{r.status}</p>
                  </div>
                  <button onClick={() => handleDelete(r.id, r.name, r.status)} className="w-10 h-10 bg-[#FEE2E2] hover:bg-[#EF4444] text-[#EF4444] hover:text-white rounded-lg font-bold transition-colors flex items-center justify-center">
                    🗑️
                  </button>
                </div>
              ))}
              {rooms.length === 0 && !loading && (
                 <p className="text-gray-500 italic col-span-2 text-center py-10">Chưa có phòng nào. Sếp hãy nhập tên phòng ở cột bên trái nhé!</p>
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
