"use client";
import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";

export default function EmployeesManager() {
  const currentBranchId = "Q1";
  const [users, setUsers] = useState([]);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(true);

  // Danh sách các quyền cốt lõi giống hệt app Python
  const PERMISSIONS = [
    { id: "QL_PHONG", name: "Quản lý Phòng & Nhóm" },
    { id: "QL_COMBO", name: "Quản lý Combo" },
    { id: "QL_DICHVU", name: "Quản lý Dịch vụ" },
    { id: "THU_CHI", name: "Xem Sổ Thu/Chi" },
    { id: "THONG_KE", name: "Xem Thống kê" }
  ];

  useEffect(() => { fetchUsers(); }, []);

  const fetchUsers = async () => {
    setLoading(true);
    const { data } = await supabase.from('app_users').select('*').eq('branch_id', currentBranchId).order('role');
    setUsers(data || []);
    setLoading(false);
  };

  const handleCreateEmp = async (e) => {
    e.preventDefault();
    if (!email.trim() || !password) return alert("Nhập đủ Email và Mật khẩu!");
    setLoading(true);
    
    // Ghi dữ liệu vào bảng app_users (Phần đăng ký Auth thực tế sẽ chạy ngầm qua Supabase)
    const { error } = await supabase.from('app_users').insert([{ 
      email: email.trim(), 
      role: 'STAFF', 
      branch_id: currentBranchId, 
      permissions: '' 
    }]);

    if (error) alert("❌ Lỗi tạo nhân viên: " + error.message);
    else {
      alert(`✅ Đã tạo thành công tài khoản: ${email}`);
      setEmail(""); setPassword("");
      fetchUsers();
    }
    setLoading(false);
  };

  const handleDelete = async (id, empEmail, role) => {
    if (role === 'MANAGER' || role === 'SUPER_ADMIN') return alert("❌ Không thể xóa Quản lý hoặc Admin!");
    if (!window.confirm(`Xóa VĨNH VIỄN nhân viên [${empEmail}]?`)) return;
    
    setLoading(true);
    await supabase.from('app_users').delete().eq('id', id);
    fetchUsers();
    setLoading(false);
  };

  const togglePermission = async (user, permId) => {
    let currentPerms = user.permissions ? user.permissions.split(',') : [];
    
    if (currentPerms.includes(permId)) {
      currentPerms = currentPerms.filter(p => p !== permId); // Xóa quyền
    } else {
      currentPerms.push(permId); // Thêm quyền
    }
    
    const newPermsStr = currentPerms.join(',');
    await supabase.from('app_users').update({ permissions: newPermsStr }).eq('id', user.id);
    fetchUsers(); // Refresh lại bảng
  };

  return (
    <div className="flex flex-col h-full space-y-4">
      <div className="bg-white p-6 rounded-2xl border border-[#B7E4C7]">
        <h2 className="text-2xl font-bold text-[#2D6A4F]">👨‍💼 QUẢN LÝ NHÂN SỰ & PHÂN QUYỀN</h2>
        <p className="text-[#5A7C68]">Tạo tài khoản Lễ tân và cấp quyền thao tác trên hệ thống.</p>
      </div>

      <div className="flex-1 grid grid-cols-12 gap-6 overflow-hidden">
        
        {/* CỘT TRÁI: FORM TẠO NHÂN VIÊN */}
        <div className="col-span-4 bg-white p-6 rounded-2xl border border-[#B7E4C7] h-fit shadow-sm">
          <h3 className="text-lg font-bold text-[#18392B] mb-4">➕ Tạo tài khoản Lễ tân</h3>
          <form onSubmit={handleCreateEmp} className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Email đăng nhập</label>
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="VD: letan1@gmail.com" className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-[#52B788] outline-none" required />
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Mật khẩu</label>
              <input type="text" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Nhập mật khẩu..." className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-[#52B788] outline-none font-bold" required />
            </div>
            <button type="submit" disabled={loading} className="w-full py-3 bg-[#F57C00] hover:bg-[#E65100] text-white font-bold rounded-xl transition-colors mt-2 shadow-md">
              {loading ? "⏳ Đang tạo..." : "💾 TẠO TÀI KHOẢN"}
            </button>
          </form>
        </div>

        {/* CỘT PHẢI: DANH SÁCH & PHÂN QUYỀN */}
        <div className="col-span-8 bg-white rounded-2xl border border-[#B7E4C7] flex flex-col overflow-hidden shadow-sm">
          <h3 className="text-lg font-bold text-[#18392B] p-6 pb-2 border-b border-[#EAF7EA]">📋 Danh sách Nhân sự {loading && "⏳"}</h3>
          
          <div className="flex-1 overflow-y-auto p-6 bg-[#F7FFF9] custom-scrollbar space-y-4">
            {users.map(u => {
              const isManager = u.role === 'MANAGER' || u.role === 'SUPER_ADMIN';
              const userPerms = u.permissions ? u.permissions.split(',') : [];
              
              return (
                <div key={u.id} className="bg-white p-5 rounded-xl border border-[#B7E4C7] shadow-sm flex flex-col">
                  <div className="flex justify-between items-center mb-4 border-b border-gray-100 pb-3">
                    <div>
                      <p className="font-bold text-[#18392B] text-lg">👤 {u.email}</p>
                      <p className={`text-sm font-bold mt-1 ${isManager ? 'text-red-600' : 'text-[#2D6A4F]'}`}>
                        {isManager ? '👑 QUẢN LÝ / VUA (Full Quyền)' : '👨‍💼 LỄ TÂN'}
                      </p>
                    </div>
                    {!isManager && (
                      <button onClick={() => handleDelete(u.id, u.email, u.role)} className="px-4 py-2 bg-[#FEE2E2] hover:bg-[#EF4444] text-[#EF4444] hover:text-white rounded-lg font-bold transition-colors">
                        🗑️ Xóa Lễ Tân
                      </button>
                    )}
                  </div>

                  {/* BẢNG CẤP QUYỀN (Chỉ hiển thị cho Lễ Tân) */}
                  {!isManager && (
                    <div>
                      <p className="text-sm font-bold text-gray-700 mb-2">✅ Bật/Tắt Quyền Truy Cập:</p>
                      <div className="grid grid-cols-2 gap-3">
                        {PERMISSIONS.map(p => {
                          const hasPerm = userPerms.includes(p.id);
                          return (
                            <label key={p.id} className={`flex items-center p-3 rounded-lg border cursor-pointer transition-colors ${hasPerm ? 'bg-[#EAF7EA] border-[#52B788]' : 'bg-gray-50 border-gray-200 hover:bg-gray-100'}`}>
                              <input 
                                type="checkbox" 
                                checked={hasPerm} 
                                onChange={() => togglePermission(u, p.id)}
                                className="w-5 h-5 text-[#2D6A4F] rounded border-gray-300 focus:ring-[#2D6A4F] cursor-pointer"
                              />
                              <span className={`ml-3 font-medium ${hasPerm ? 'text-[#18392B]' : 'text-gray-500'}`}>{p.name}</span>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
}