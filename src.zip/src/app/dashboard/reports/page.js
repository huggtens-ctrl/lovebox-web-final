"use client";
import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";
import { money } from "@/lib/utils";

export default function ReportsManager() {
  const currentBranchId = "Q1";
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]); // Mặc định hôm nay
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => { fetchReport(); }, [date]);

  const fetchReport = async () => {
    setLoading(true);
    // Rút toàn bộ Hóa đơn đã thanh toán trong ngày
    const { data } = await supabase.from('orders').select('*').eq('branch_id', currentBranchId).eq('status', 'ĐÃ THANH TOÁN').like('paid_at', `${date}%`).order('paid_at', { ascending: false });
    setOrders(data || []);
    setLoading(false);
  };

  const totalCash = orders.reduce((sum, o) => sum + parseInt(o.cash_amount || 0), 0);
  const totalTransfer = orders.reduce((sum, o) => sum + parseInt(o.transfer_amount || 0), 0);
  const totalMoney = orders.reduce((sum, o) => sum + parseInt(o.total_money || 0), 0);

  return (
    <div className="flex flex-col h-full space-y-4">
      <div className="bg-white p-6 rounded-2xl border border-[#B7E4C7] flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-[#2D6A4F]">📅 BÁO CÁO DOANH THU</h2>
          <p className="text-[#5A7C68]">Chỉ hiển thị các Hóa đơn đã chốt Thanh toán</p>
        </div>
        <input type="date" value={date} onChange={e=>setDate(e.target.value)} className="px-4 py-3 border border-gray-300 rounded-xl font-bold text-lg outline-none focus:ring-2 focus:ring-[#52B788]" />
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-[#EAF7EA] p-6 rounded-xl border border-[#B7E4C7] text-center"><p className="text-sm font-bold text-[#2D6A4F]">💵 TỔNG TIỀN MẶT</p><p className="text-3xl font-bold text-[#2E7D32] mt-2">{money(totalCash)}</p></div>
        <div className="bg-[#E3F2FD] p-6 rounded-xl border border-blue-200 text-center"><p className="text-sm font-bold text-blue-800">🏦 TỔNG CHUYỂN KHOẢN</p><p className="text-3xl font-bold text-[#1976D2] mt-2">{money(totalTransfer)}</p></div>
        <div className="bg-[#FFF8E1] p-6 rounded-xl border border-yellow-200 text-center"><p className="text-sm font-bold text-yellow-800">💰 TỔNG CẦN THU (RÒNG)</p><p className="text-3xl font-bold text-[#D32F2F] mt-2">{money(totalMoney)}</p></div>
      </div>

      <div className="flex-1 bg-white p-6 rounded-2xl border border-[#B7E4C7] overflow-y-auto">
        <h3 className="font-bold text-lg mb-4 border-b pb-2">🧾 Chi tiết Hóa đơn trong ngày {loading && "⏳..."}</h3>
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-100 text-gray-700">
              <th className="p-3 border-b">Mã HĐ</th>
              <th className="p-3 border-b">Khách hàng</th>
              <th className="p-3 border-b">Giờ chốt</th>
              <th className="p-3 border-b text-right">Tiền mặt</th>
              <th className="p-3 border-b text-right">Thẻ/CK</th>
              <th className="p-3 border-b text-right">Tổng (VND)</th>
            </tr>
          </thead>
          <tbody>
            {orders.map(o => (
              <tr key={o.id} className="hover:bg-gray-50 transition-colors">
                <td className="p-3 border-b font-bold text-[#18392B]">#{o.id}</td>
                <td className="p-3 border-b font-medium">{o.customer_name || 'Khách lẻ'}</td>
                <td className="p-3 border-b">{o.paid_at.split(' ')[1]}</td>
                <td className="p-3 border-b text-right font-medium text-[#2E7D32]">{money(o.cash_amount)}</td>
                <td className="p-3 border-b text-right font-medium text-[#1976D2]">{money(o.transfer_amount)}</td>
                <td className="p-3 border-b text-right font-bold text-red-600">{money(o.total_money)}</td>
              </tr>
            ))}
            {orders.length === 0 && !loading && (<tr><td colSpan="6" className="p-6 text-center text-gray-500 italic">Không có hóa đơn nào trong ngày này.</td></tr>)}
          </tbody>
        </table>
      </div>
    </div>
  );
}