"use client";
import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";

export default function CustomersManager() {
  const currentBranchId = "Q1";
  const [customers, setCustomers] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchCustomers(); }, []);

  const fetchCustomers = async () => {
    setLoading(true);
    // Quét trực tiếp từ Hóa đơn giống hệt bản Python
    const { data } = await supabase.from('orders').select('customer_name, id').eq('branch_id', currentBranchId).not('customer_name', 'is', null).not('customer_name', 'eq', '');
    
    // Gộp và đếm số lần đến
    const counts = {};
    (data || []).forEach(o => {
      const name = o.customer_name.trim();
      counts[name] = (counts[name] || 0) + 1;
    });
    
    const arr = Object.keys(counts).map(k => ({ name: k, count: counts[k] })).sort((a, b) => b.count - a.count);
    setCustomers(arr);
    setLoading(false);
  };

  const displayCustomers = customers.filter(c => c.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="flex flex-col h-full space-y-4">
      <div className="bg-white p-6 rounded-2xl border border-[#B7E4C7]">
        <h2 className="text-2xl font-bold text-[#2D6A4F]">📒 DANH SÁCH KHÁCH QUEN</h2>
        <p className="text-[#5A7C68]">Hệ thống tự động quét từ các Hóa đơn cũ.</p>
        <input type="text" value={search} onChange={e=>setSearch(e.target.value)} placeholder="🔍 Nhập Tên/SĐT để tìm..." className="mt-4 w-full p-3 border rounded-xl bg-[#F7FFF9]" />
      </div>
      <div className="flex-1 bg-white p-6 rounded-2xl border border-[#B7E4C7] overflow-y-auto">
        {loading ? <p>⏳ Đang quét dữ liệu...</p> : (
          <div className="grid grid-cols-3 gap-4">
            {displayCustomers.map((c, i) => (
              <div key={i} className="p-4 border border-[#B7E4C7] rounded-xl flex justify-between items-center bg-[#F4FFF7]">
                <span className="font-bold text-[#18392B]">👤 {c.name}</span>
                <span className="text-sm font-bold text-white bg-[#F57C00] px-3 py-1 rounded-full">Đến {c.count} lần</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}