"use client";
import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";
import { money, nowStr } from "@/lib/utils";

export default function CashbookManager() {
  const currentBranchId = "Q1";
  const [records, setRecords] = useState([]);
  const [amount, setAmount] = useState("");
  const [reason, setReason] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchRecords(); }, []);

  const fetchRecords = async () => {
    setLoading(true);
    const { data } = await supabase.from('cashbook').select('*').eq('branch_id', currentBranchId).order('created_at', { ascending: false }).limit(100);
    setRecords(data || []);
    setLoading(false);
  };

  const handleAdd = async (type) => {
    if (!amount || !reason) return alert("Nhập đủ Tiền và Lý do!");
    setLoading(true);
    await supabase.from('cashbook').insert([{ type, amount: parseInt(amount), reason, branch_id: currentBranchId, created_at: nowStr() }]);
    setAmount(""); setReason(""); fetchRecords();
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Xóa phiếu này?")) return;
    await supabase.from('cashbook').delete().eq('id', id);
    fetchRecords();
  };

  return (
    <div className="flex flex-col h-full space-y-4">
      <h2 className="text-2xl font-bold text-[#2D6A4F] bg-white p-6 rounded-2xl border border-[#B7E4C7]">💸 QUẢN LÝ THU / CHI NGOÀI</h2>
      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-1 bg-white p-6 rounded-2xl border border-[#B7E4C7] h-fit space-y-4">
          <h3 className="font-bold text-lg">📝 Tạo Phiếu Mới</h3>
          <input type="number" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="Số tiền (VND)..." className="w-full p-3 border rounded-xl font-bold" />
          <input type="text" value={reason} onChange={e=>setReason(e.target.value)} placeholder="Lý do thu/chi..." className="w-full p-3 border rounded-xl" />
          <div className="flex space-x-2">
            <button onClick={()=>handleAdd('THU')} disabled={loading} className="w-1/2 py-3 bg-[#2E7D32] text-white font-bold rounded-xl">📥 LÀM PHIẾU THU</button>
            <button onClick={()=>handleAdd('CHI')} disabled={loading} className="w-1/2 py-3 bg-[#D32F2F] text-white font-bold rounded-xl">📤 LÀM PHIẾU CHI</button>
          </div>
        </div>
        <div className="col-span-2 bg-white p-6 rounded-2xl border border-[#B7E4C7] overflow-y-auto max-h-[70vh]">
          <h3 className="font-bold text-lg mb-4 border-b pb-2">📋 Lịch sử giao dịch</h3>
          <div className="space-y-3">
            {records.map(r => (
              <div key={r.id} className="flex justify-between items-center p-4 border rounded-xl bg-gray-50">
                <div>
                  <span className={`font-bold px-2 py-1 rounded text-white ${r.type === 'THU' ? 'bg-[#2E7D32]' : 'bg-[#D32F2F]'}`}>{r.type}</span>
                  <span className="ml-3 font-bold text-lg">{money(r.amount)}</span>
                  <p className="text-sm text-gray-600 mt-1">🕒 {r.created_at} | 📝 {r.reason}</p>
                </div>
                <button onClick={() => handleDelete(r.id)} className="px-3 py-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-500 hover:text-white font-bold">🗑️</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}