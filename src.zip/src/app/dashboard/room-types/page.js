"use client";
import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";

export default function RoomTypesManager() {
  const currentBranchId = "Q1"; 
  const [groups, setGroups] = useState([]);
  const [newName, setNewName] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchGroups(); }, []);

  const fetchGroups = async () => {
    setLoading(true);
    const { data } = await supabase.from('room_types').select('*').eq('branch_id', currentBranchId).order('name');
    setGroups(data || []);
    setLoading(false);
  };

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!newName.trim()) return alert("Vui lòng nhập tên!");
    setLoading(true);
    await supabase.from('room_types').insert([{ name: newName.trim(), branch_id: currentBranchId }]);
    setNewName("");
    fetchGroups();
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Xóa nhóm [${name}]?`)) return;
    setLoading(true);
    await supabase.from('room_types').delete().eq('id', id);
    fetchGroups();
  };

  return (
    <div className="flex flex-col h-full space-y-4">
      <h2 className="text-2xl font-bold text-[#2D6A4F] bg-white p-6 rounded-2xl border border-[#B7E4C7]">🏷️ QUẢN LÝ NHÓM PHÒNG</h2>
      <div className="grid grid-cols-3 gap-6">
        {/* Khung Thêm */}
        <div className="col-span-1 bg-white p-6 rounded-2xl border border-[#B7E4C7] h-fit">
          <h3 className="text-lg font-bold mb-4">➕ Thêm nhóm</h3>
          <form onSubmit={handleAdd}>
            <input type="text" value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Tên nhóm..." className="w-full px-4 py-3 rounded-xl border mb-4 focus:ring-2 focus:ring-[#52B788] outline-none" required />
            <button disabled={loading} className="w-full py-3 bg-[#2D6A4F] text-white font-bold rounded-xl">{loading ? "⏳..." : "LƯU"}</button>
          </form>
        </div>
        {/* Khung Danh sách */}
        <div className="col-span-2 bg-white p-6 rounded-2xl border border-[#B7E4C7]">
          <h3 className="text-lg font-bold mb-4 border-b pb-2">📋 Danh sách</h3>
          <div className="space-y-3">
            {groups.map(g => (
              <div key={g.id} className="flex justify-between items-center p-4 bg-[#F7FFF9] border border-[#B7E4C7] rounded-xl">
                <span className="font-bold text-[#18392B] text-lg">{g.name}</span>
                <button onClick={() => handleDelete(g.id, g.name)} className="px-4 py-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-500 hover:text-white font-bold transition-colors">🗑️ Xóa</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}