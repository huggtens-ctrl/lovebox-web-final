// src/app/dashboard/layout.js
"use client";
"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function DashboardLayout({ children }) {
  const router = useRouter();
  
  // Tạm thời hardcode thông tin user, phần sau anh em mình sẽ lấy từ Supabase
  const currentUser = { email: "quanly@gmail.com", role: "MANAGER", branch_id: "Q1" };
  
  // Danh sách Menu dựa theo quyền giống hệt bản Python v8
  // Danh sách Menu đã được gắn định tuyến (path)
  const menuGroups = [
    {
      title: "🏨 CẤU HÌNH CHI NHÁNH",
      items: [
        { name: "🏠 Tổng quan quầy", icon: "🏠", path: "/dashboard" },
        { name: "🚪 Quản lý Sơ đồ Phòng", icon: "🚪", path: "/dashboard/rooms" }, // <-- Dòng mới thêm
        { name: "🏷️ Nhóm phòng", icon: "🏷️", path: "/dashboard/room-types" },
        { name: "💎 Combo phòng", icon: "💎", path: "/dashboard/combos" },
        { name: "🍔 Dịch vụ", icon: "🍔", path: "/dashboard/services" },
        { name: "📒 Khách quen", icon: "📒", path: "/dashboard/customers" }
      ]
    },
    {
      title: "🏨 CẤU HÌNH CHI NHÁNH",
      items: [
        { name: "🏠 Tổng quan quầy", icon: "🏠", path: "/dashboard" },
        { name: "🏷️ Nhóm phòng", icon: "🏷️", path: "/dashboard/room-types" },
        { name: "💎 Combo phòng", icon: "💎", path: "/dashboard/combos" },
        { name: "🍔 Dịch vụ", icon: "🍔", path: "/dashboard/services" },
        { name: "📒 Khách quen", icon: "📒", path: "/dashboard/customers" }
      ]
    },
    {
      title: "📊 QUỸ & BÁO CÁO",
      items: [
        { name: "💸 Sổ Thu / Chi", icon: "💸", path: "/dashboard/cashbook" },
        { name: "📅 Thống kê Doanh thu", icon: "📅", path: "/dashboard/reports" }
      ]
    },
    {
      title: "👥 NHÂN SỰ",
      items: [
        { name: "👨‍💼 Phân quyền Nhân viên", icon: "👨‍💼", path: "/dashboard/employees" }
      ]
    }
  ];

  const handleLogout = () => {
    // Xóa bộ nhớ và đá văng ra màn hình đăng nhập
    alert("Đăng xuất thành công!");
    router.push("/");
  };

  return (
    <div className="flex h-screen bg-[#EAF7EA] overflow-hidden font-sans">
      
      {/* CỘT TRÁI: SIDEBAR (Menu) */}
      <div className="w-72 bg-[#2D6A4F] text-white flex flex-col shadow-2xl z-10">
        <div className="p-6">
          <h1 className="text-2xl font-bold tracking-wider">🏨 LOVEBOX BILL</h1>
        </div>
        
        {/* Vùng cuộn Menu */}
        <div className="flex-1 overflow-y-auto px-4 custom-scrollbar">
          {menuGroups.map((group, idx) => (
            <div key={idx} className="mb-6">
              <h2 className="text-[#A3E4D7] text-sm font-bold mb-3 pl-2">{group.title}</h2>
              {group.items.map((item, i) => (
                <button
                  key={i}
                  onClick={() => item.path ? router.push(item.path) : alert("🚧 Sẽ làm ở lát cắt tiếp theo!")}
                  className="w-full flex items-center px-4 py-3 mb-2 text-left bg-[#40916C] hover:bg-[#52B788] rounded-xl transition-all font-medium"
                >
                  <span className="mr-3">{item.icon}</span>
                  {item.name}
                </button>
              ))}
            </div>
          ))}
        </div>
        
        {/* Nút đăng xuất dưới cùng */}
        <div className="p-4 border-t border-[#40916C]">
          <button 
            onClick={handleLogout}
            className="w-full py-3 bg-[#EF4444] hover:bg-[#B71C1C] rounded-xl font-bold transition-all shadow-md"
          >
            👋 ĐĂNG XUẤT
          </button>
        </div>
      </div>

      {/* CỘT PHẢI: NỘI DUNG CHÍNH */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        
        {/* THANH HEADER TIÊU ĐỀ */}
        <header className="px-8 py-5 flex justify-between items-center bg-[#EAF7EA]">
          <div>
            <h1 className="text-3xl font-bold text-[#2D6A4F]">🏨 HỆ THỐNG LOVEBOX BILL CLOUD</h1>
            <p className="text-[#2D6A4F] font-bold mt-1 text-sm">
              Chi nhánh {currentUser.branch_id} | Tài khoản QUẢN LÝ: {currentUser.email}
            </p>
          </div>
          <div className="text-[#2D6A4F] text-sm font-bold italic opacity-80">
            ✨Created by ViecGiKhoCoHungLo ver Web✨
          </div>
        </header>

        {/* KHUNG CHỨA NỘI DUNG ĐỘNG (Sẽ nhét Sơ đồ phòng vào đây) */}
        <main className="flex-1 overflow-y-auto p-8 pt-0">
          {children}
        </main>

      </div>
    </div>
  );
}