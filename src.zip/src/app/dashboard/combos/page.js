"use client";
import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";
import { money } from "@/lib/utils";

export default function ComboManager() {
  const currentBranchId = "Q1"; 
  const [types, setTypes] = useState([]);
  const [selectedType, setSelectedType] = useState(null);
  const [combos, setCombos] = useState([]);
  const [loading, setLoading] = useState(true);

  // Form
  const [name, setName] = useState("");
  const [hours, setHours] = useState("");
  const [minutes, setMinutes] = useState("");
  const [price, setPrice] = useState("");

  useEffect(() => { fetchTypes(); }, []);
  useEffect(() => { if (selectedType) fetchCombos(); }, [selectedType]);

  const fetchTypes = async () => {
    const { data } = await supabase.from('room_types').select('*').eq('branch_id', currentBranchId).order('name');
    setTypes(data || []);
    if (data?.length > 0) setSelectedType(data[0].id);
  };

  const fetchCombos = async () => {
    setLoading(true);
    const { data } = await supabase.from('room_combos').select('*').eq('room_type_id', selectedType).eq('is_active', 1).order('hours');
    setCombos(data || []);
    setLoading(false);
  };

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!name || !price) return alert("Nhập đủ Tên và Giá!");
    setLoading(true);
    await supabase.from('room_combos').insert([{
      name, hours: parseInt(hours || 0), minutes: parseInt(minutes || 0), price: parseInt(price),
      room_type_id: selectedType, branch_id: currentBranchId, is_active: 1
    }]);
    setName(""); setHours(""); setMinutes(""); setPrice("");
    fetchCombos();
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Xóa combo này?")) return;
    await supabase.from('room_combos').delete().eq('id', id);
    fetchCombos();
  };

  return (
    <div className="flex flex-col h-full space-y-4">
      <div className="bg-white p-6 rounded-2xl border border-[#B7E4C7] flex justify-between items-center">
        <h2 className="text-2xl font-bold text-[#2D6A4F]">💎 QUẢN LÝ COMBO</h2>
        <select value={selectedType || ''} onChange={(e) => setSelectedType(e.target.value)} className="px-4 py-2 border rounded-lg font-bold outline-none">
          {types.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
        </select>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Form Thêm */}
        <div className="col-span-1 bg-white p-6 rounded-2xl border border-[#B7E4C7] h-fit space-y-4">
          <h3 className="font-bold text-lg">➕ Thêm Combo mới</h3>
          <form onSubmit={handleAdd} className="space-y-3">
            <input type="text" value={name} onChange={e=>setName(e.target.value)} placeholder="Tên (VD: Combo Đêm)" className="w-full p-3 border rounded-xl" required/>
            <div className="flex space-x-2">
              <input type="number" value={hours} onChange={e=>setHours(e.target.value)} placeholder="Giờ" className="w-1/2 p-3 border rounded-xl"/>
              <input type="number" value={minutes} onChange={e=>setMinutes(e.target.value)} placeholder="Phút" className="w-1/2 p-3 border rounded-xl"/>
            </div>
            <input type="number" value={price} onChange={e=>setPrice(e.target.value)} placeholder="Giá tiền (VND)" className="w-full p-3 border rounded-xl font-bold" required/>
            <button disabled={loading} className="w-full py-3 bg-[#1976D2] text-white font-bold rounded-xl">{loading ? "⏳..." : "LƯU COMBO"}</button>
          </form>
        </div>

        {/* Danh sách */}
        <div className="col-span-2 bg-white p-6 rounded-2xl border border-[#B7E4C7]">
          <h3 className="font-bold text-lg mb-4 border-b pb-2">📋 Danh sách Combo {loading && "⏳"}</h3>
          <div className="grid grid-cols-2 gap-4">
            {combos.map(c => (
              <div key={c.id} className="p-4 bg-[#F0F8FF] border border-blue-200 rounded-xl flex flex-col justify-between">
                <div>
                  <p className="font-bold text-lg">{c.name}</p>
                  <p className="text-sm text-gray-600">Thời gian: {c.hours}h {c.minutes}m</p>
                  <p className="font-bold text-blue-700 mt-1">{money(c.price)}</p>
                </div>
                <button onClick={() => handleDelete(c.id)} className="mt-3 py-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-500 hover:text-white font-bold text-sm">🗑️ Xóa</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}