"use client";
import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";
import { money } from "@/lib/utils";

export default function ServicesManager() {
  const currentBranchId = "Q1"; // Tạm fix cứng nhánh Q1
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // State cho form thêm món mới
  const [newName, setNewName] = useState("");
  const [newPrice, setNewPrice] = useState("");

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    setLoading(true);
    const { data } = await supabase.from('services').select('*').eq('branch_id', currentBranchId).order('name');
    setServices(data || []);
    setLoading(false);
  };

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!newName.trim() || !newPrice) return alert("Vui lòng nhập đủ Tên món và Giá tiền!");
    
    setLoading(true);
    const { error } = await supabase.from('services').insert([{ 
      name: newName.trim(), 
      price: parseInt(newPrice.replace(/\D/g, '') || 0), 
      branch_id: currentBranchId 
    }]);
    
    if (error) alert("❌ Lỗi thêm món: " + error.message);
    else {
      setNewName("");
      setNewPrice("");
      fetchServices(); // Tải lại danh sách
    }
    setLoading(false);
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Sếp có chắc muốn XÓA món [${name}] khỏi Menu không?`)) return;
    
    setLoading(true);
    const { error } = await supabase.from('services').delete().eq('id', id);
    if (error) alert("❌ Lỗi xóa món: " + error.message);
    else fetchServices();
    setLoading(false);
  };

  return (
    <div className="flex flex-col h-full space-y-4">
      <div className="bg-white p-6 rounded-2xl border border-[#B7E4C7] shadow-sm">
        <h2 className="text-2xl font-bold text-[#2D6A4F] mb-2">🍔 QUẢN LÝ MENU DỊCH VỤ</h2>
        <p className="text-[#5A7C68]">Thêm, sửa, xóa đồ ăn thức uống cho chi nhánh {currentBranchId}</p>
      </div>

      <div className="flex-1 grid grid-cols-3 gap-6 overflow-hidden">
        {/* Cột Trái: Form Thêm Món */}
        <div className="col-span-1 bg-white p-6 rounded-2xl border border-[#B7E4C7] shadow-sm h-fit">
          <h3 className="text-lg font-bold text-[#18392B] mb-4">➕ Thêm món mới</h3>
          <form onSubmit={handleAdd} className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Tên món</label>
              <input type="text" value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="VD: Bò húc" className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-[#52B788] outline-none" required />
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Giá bán (VND)</label>
              <input type="number" value={newPrice} onChange={(e) => setNewPrice(e.target.value)} placeholder="VD: 25000" className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-[#52B788] outline-none font-bold" required />
            </div>
            <button type="submit" disabled={loading} className="w-full py-3 bg-[#F57C00] hover:bg-[#E65100] text-white font-bold rounded-xl transition-colors mt-2">
              {loading ? "⏳ Đang xử lý..." : "💾 LƯU VÀO MENU"}
            </button>
          </form>
        </div>

        {/* Cột Phải: Danh sách Món */}
        <div className="col-span-2 bg-white rounded-2xl border border-[#B7E4C7] shadow-sm flex flex-col overflow-hidden">
          <h3 className="text-lg font-bold text-[#18392B] p-6 pb-2 border-b border-[#EAF7EA]">📋 Danh sách hiện tại {loading && "⏳"}</h3>
          <div className="flex-1 overflow-y-auto p-6 bg-[#F7FFF9] custom-scrollbar">
            <div className="grid grid-cols-2 gap-4">
              {services.map(s => (
                <div key={s.id} className="bg-white p-4 rounded-xl border border-[#B7E4C7] flex justify-between items-center shadow-sm">
                  <div>
                    <p className="font-bold text-[#18392B] text-lg">{s.name}</p>
                    <p className="text-[#2D6A4F] font-bold mt-1">{money(s.price)}</p>
                  </div>
                  <button onClick={() => handleDelete(s.id, s.name)} className="w-10 h-10 bg-[#FEE2E2] hover:bg-[#EF4444] text-[#EF4444] hover:text-white rounded-lg font-bold transition-colors flex items-center justify-center">
                    🗑️
                  </button>
                </div>
              ))}
              {services.length === 0 && !loading && (
                 <p className="text-gray-500 italic col-span-2 text-center py-10">Chưa có món nào trong Menu.</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}