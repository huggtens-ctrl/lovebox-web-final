"use client";
import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";
import { money } from "@/lib/utils";

export default function RoomModal({ isOpen, room, onClose }) {
  const [view, setView] = useState("menu"); // 'menu', 'checkin', 'service', 'checkout'
  const [loading, setLoading] = useState(false);

  // --- STATE NHẬN PHÒNG ---
  const [combos, setCombos] = useState([]);
  const [selectedCombo, setSelectedCombo] = useState(null);
  const [customerName, setCustomerName] = useState("");
  const [checkinTime, setCheckinTime] = useState("");

  // --- STATE DỊCH VỤ ---
  const [services, setServices] = useState([]);
  const [selectedService, setSelectedService] = useState(null);
  const [quantity, setQuantity] = useState(1);

  // --- STATE TRẢ PHÒNG ---
  const [checkoutData, setCheckoutData] = useState({ 
    roomMoney: 0, serviceMoney: 0, adjustMoney: 0, discount: 0, total: 0 
  });
  const [checkoutTime, setCheckoutTime] = useState("");
  const [cashAmount, setCashAmount] = useState("");
  const [transferAmount, setTransferAmount] = useState("");

  useEffect(() => {
    if (isOpen) {
      setView("menu");
      setQuantity(1);
      setCashAmount("");
      setTransferAmount("");
    }
  }, [isOpen, room]);

  if (!isOpen || !room) return null;
  const isActive = room.status === "ĐANG THUÊ";
  const order = room.activeOrder;

  // ================= 1. XỬ LÝ NHẬN PHÒNG =================
  const handleOpenCheckin = async () => {
    if (isActive) return alert("Phòng đang có khách!");
    setLoading(true);
    setView("checkin");
    const now = new Date();
    setCheckinTime(`${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`);
    const { data } = await supabase.from('room_combos').select('*').eq('is_active', 1).eq('room_type_id', room.room_type_id).order('hours');
    setCombos(data || []);
    if (data?.length) setSelectedCombo(data[0]);
    setLoading(false);
  };

  const handleCheckinSubmit = async () => {
    if (!selectedCombo) return alert("Vui lòng chọn Combo!");
    setLoading(true);
    try {
      const [hh, mm] = checkinTime.split(":");
      const checkinDate = new Date();
      checkinDate.setHours(parseInt(hh), parseInt(mm), 0, 0);
      const checkoutDate = new Date(checkinDate.getTime());
      checkoutDate.setHours(checkoutDate.getHours() + selectedCombo.hours);
      checkoutDate.setMinutes(checkoutDate.getMinutes() + selectedCombo.minutes);

      const offset = checkinDate.getTimezoneOffset() * 60000;
      const localCheckin = (new Date(checkinDate - offset)).toISOString().slice(0, 19).replace('T', ' ');
      const localCheckout = (new Date(checkoutDate - offset)).toISOString().slice(0, 19).replace('T', ' ');

      // Ép Két sắt báo lỗi thẳng mặt nếu có sự cố, không cho chạy ngầm
      const { error: orderError } = await supabase.from('orders').insert([{
        room_id: room.id, 
        customer_name: customerName.trim() || 'Khách lẻ', 
        checkin_time: localCheckin, 
        expected_checkout_time: localCheckout,
        combo_id: selectedCombo.id, 
        combo_name: selectedCombo.name, 
        combo_hours: selectedCombo.hours, 
        combo_minutes: selectedCombo.minutes,
        combo_price: selectedCombo.price, 
        extra_minutes: 0, 
        extra_money: 0, 
        adjustment_money: 0, 
        adjustment_reason: '',
        room_money: selectedCombo.price, 
        status: 'ĐANG THUÊ', 
        branch_id: room.branch_id,
        created_at: new Date().toISOString(),
        created_by_username: 'quanly@gmail.com'
      }]);

      if (orderError) {
        alert("❌ LỖI TẠO HÓA ĐƠN: " + orderError.message);
        setLoading(false);
        return; // Chặn đứng, không cho đổi màu phòng
      }

      const { error: roomError } = await supabase.from('rooms').update({ status: 'ĐANG THUÊ' }).eq('id', room.id);
      if (roomError) {
        alert("❌ LỖI ĐỔI MÀU PHÒNG: " + roomError.message);
        setLoading(false);
        return;
      }

      onClose();
    } catch (error) { alert("Lỗi hệ thống: " + error.message); }
    setLoading(false);
  };

  // ================= 2. XỬ LÝ GỌI DỊCH VỤ =================
  const handleOpenService = async () => {
    // Chặn cửa ngay nếu Hóa đơn chưa đồng bộ kịp về Web
    if (!isActive || !order) return alert("⏳ Đang đồng bộ Hóa đơn mới, sếp đợi 1 giây rồi bấm lại nhé!");
    
    setLoading(true);
    setView("service");
    const { data } = await supabase.from('services').select('*').eq('branch_id', room.branch_id).order('name');
    setServices(data || []);
    if (data?.length) setSelectedService(data[0]);
    setLoading(false);
  };

  const handleServiceSubmit = async () => {
    if (!selectedService || quantity <= 0) return alert("Dữ liệu không hợp lệ!");
    if (!order) return alert("Lỗi: Không tìm thấy Mã Hóa Đơn!"); 

    setLoading(true);
    try {
      const totalItem = selectedService.price * quantity;
      
      const { error: itemError } = await supabase.from('order_items').insert([{
        order_id: order.id, 
        service_name: selectedService.name, 
        quantity: quantity, 
        price: selectedService.price, 
        total: totalItem, 
        created_at: new Date().toISOString()
      }]);

      if (itemError) {
        alert("❌ LỖI GHI MÓN: " + itemError.message);
        setLoading(false);
        return;
      }
      
      const { data: srvData } = await supabase.from('order_items').select('total').eq('order_id', order.id);
      const newServiceMoney = srvData ? srvData.reduce((sum, item) => sum + item.total, 0) : 0;
      await supabase.from('orders').update({ service_money: newServiceMoney }).eq('id', order.id);
      
      onClose();
    } catch (error) { alert("Lỗi hệ thống: " + error.message); }
    setLoading(false);
  };

  // ================= 3. XỬ LÝ TRẢ PHÒNG (2 Nhát Búa) =================
  const handleOpenCheckout = async () => {
    if (!isActive) return alert("Phòng chưa có khách!");
    setLoading(true);
    setView("checkout");
    
    // Tính toán tiền realtime
    const roomMoney = parseInt(order.combo_price || 0) + parseInt(order.extra_money || 0);
    const { data: srvData } = await supabase.from('order_items').select('total').eq('order_id', order.id);
    const serviceMoney = srvData ? srvData.reduce((sum, item) => sum + item.total, 0) : 0;
    const adjustMoney = parseInt(order.adjustment_money || 0);
    const total = Math.max(0, roomMoney + serviceMoney + adjustMoney);

    setCheckoutData({ roomMoney, serviceMoney, adjustMoney, discount: 0, total });
    setCashAmount(total.toString()); // Mặc định khách đưa tiền mặt chẵn
    setTransferAmount("0");

    // Lấy giờ dự kiến làm mặc định giống Python
    const expTime = new Date(order.expected_checkout_time);
    setCheckoutTime(`${String(expTime.getHours()).padStart(2, '0')}:${String(expTime.getMinutes()).padStart(2, '0')}`);
    setLoading(false);
  };

  const handleCheckoutSubmit = async () => {
    const cash = parseInt(cashAmount || 0);
    const transfer = parseInt(transferAmount || 0);
    if (cash + transfer !== checkoutData.total) {
      return alert(`Lỗi: Tiền mặt + CK đang lệch! Phải khớp Tổng Bill: ${money(checkoutData.total)}`);
    }

    setLoading(true);
    try {
      let pm = "CẢ HAI";
      if (cash === checkoutData.total) pm = "TIỀN MẶT";
      if (transfer === checkoutData.total) pm = "CHUYỂN KHOẢN";

      // Chuẩn bị giờ checkout chuẩn
      const expDate = new Date(order.expected_checkout_time);
      const [hh, mm] = checkoutTime.split(":");
      expDate.setHours(parseInt(hh), parseInt(mm), 0, 0);
      const offset = expDate.getTimezoneOffset() * 60000;
      const finalCheckoutStr = (new Date(expDate - offset)).toISOString().slice(0, 19).replace('T', ' ');

      // Nhát búa 1: Chốt sổ doanh thu hóa đơn
      await supabase.from('orders').update({
        checkout_time: finalCheckoutStr, paid_at: finalCheckoutStr,
        room_money: checkoutData.roomMoney, service_money: checkoutData.serviceMoney,
        adjustment_money: checkoutData.adjustMoney, discount: checkoutData.discount,
        total_money: checkoutData.total, payment_method: pm, cash_amount: cash, transfer_amount: transfer,
        status: 'ĐÃ THANH TOÁN', paid_by_username: "quanly@gmail.com" // Sau này lấy từ context user
      }).eq('id', order.id);

      // Nhát búa 2: Đổi trạng thái phòng thành DỌN PHÒNG
      await supabase.from('rooms').update({ status: 'DỌN PHÒNG' }).eq('id', room.id);
      
      alert("✅ ĐÃ THANH TOÁN THÀNH CÔNG!");
      onClose();
    } catch (error) { alert("Lỗi thanh toán: " + error.message); }
    setLoading(false);
  };

  // Hàm chia tiền tự động khi gõ
  const handleMoneyType = (type, val) => {
    const num = parseInt(val.replace(/\D/g, '') || 0);
    if (type === 'cash') {
      setCashAmount(num.toString());
      if (num <= checkoutData.total) setTransferAmount((checkoutData.total - num).toString());
    } else {
      setTransferAmount(num.toString());
      if (num <= checkoutData.total) setCashAmount((checkoutData.total - num).toString());
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm p-4">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden border border-[#B7E4C7] max-h-[95vh] flex flex-col">
        
        {/* Header Tĩnh */}
        <div className="bg-[#EAF7EA] px-6 py-4 flex justify-between items-center border-b border-[#B7E4C7] shrink-0">
          <div>
            <h2 className="text-2xl font-bold text-[#18392B]">🏠 {room.name}</h2>
            <p className="text-[#5A7C68] text-sm font-medium">Nhóm: {room.type_name} | Trạng thái: {room.status}</p>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-red-500 text-3xl font-bold transition-colors">&times;</button>
        </div>

        {/* Nội dung cuộn được */}
        <div className="p-6 overflow-y-auto custom-scrollbar">
          
          {/* ================= GÓC NHÌN 1: MENU ================= */}
          {view === "menu" && (
            <>
              <div className="bg-[#F4FFF7] p-4 rounded-xl border border-[#B7E4C7] mb-6 min-h-[120px]">
                {/* KHUNG GHI CHÚ */}
              {isActive && order && (
                <div className="flex items-center space-x-3 mb-6 bg-white p-3 rounded-xl border border-gray-200 shadow-sm">
                  <span className="font-bold text-gray-700">📝 Ghi chú:</span>
                  <input 
                    type="text" 
                    id="note_input"
                    defaultValue={order.note || ''} 
                    placeholder="Khách dặn gì ghi vào đây..."
                    className="flex-1 px-3 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-[#52B788]"
                  />
                  <button onClick={async () => {
                    const noteVal = document.getElementById("note_input").value;
                    setLoading(true);
                    await supabase.from('orders').update({ note: noteVal }).eq('id', order.id);
                    alert("✅ Đã lưu ghi chú!");
                    setLoading(false);
                    onClose();
                  }} className="px-4 py-2 bg-[#F59E0B] text-white font-bold rounded-lg hover:bg-[#D97706]">
                    Lưu nhanh
                  </button>
                </div>
              )}
                {isActive && order ? (
                  <div className="text-[#18392B] font-medium leading-relaxed">
                    <p className="font-bold text-lg mb-1">Mã HĐ: #{order.id} {order.customer_name ? `| Khách: ${order.customer_name}` : ""}</p>
                    <p>🕒 Giờ vào: {order.checkin_time}</p>
                    <p>🕒 Dự kiến ra: <span className="text-red-600 font-bold">{order.expected_checkout_time}</span></p>
                    <p>💎 {order.combo_name}: {money(order.combo_price)}</p>
                    <p className="font-bold text-red-600 mt-2 text-xl">💰 Tạm tính: {money(room.total)}</p>
                  </div>
                ) : (
                  <p className="text-[#5A7C68] font-medium">{room.name} - {room.status}<br/><br/>Phòng trống sẵn sàng.</p>
                )}
              </div>

              <div className="grid grid-cols-3 gap-3">
                <button onClick={handleOpenCheckin} className="py-4 bg-[#2E7D32] hover:bg-[#1B5E20] text-white rounded-xl font-bold">📥 Nhận phòng</button>
                <button onClick={handleOpenService} className="py-4 bg-[#F57C00] hover:bg-[#E65100] text-white rounded-xl font-bold">🍔 Thêm dịch vụ</button>
                
                <button onClick={async () => {
                  if (!isActive) return alert("Phòng chưa có khách!");
                  const { data } = await supabase.from('order_items').select('*').eq('order_id', order.id);
                  if (!data || data.length === 0) return alert("Chưa gọi món nào!");
                  let list = data.map(i => `ID: ${i.id} | ${i.service_name} (x${i.quantity})`).join('\n');
                  const delId = window.prompt(`Danh sách món:\n${list}\n\nNhập ID món muốn XÓA TOÀN BỘ:`);
                  if (delId) {
                    setLoading(true);
                    await supabase.from('order_items').delete().eq('id', delId);
                    const { data: srvData } = await supabase.from('order_items').select('total').eq('order_id', order.id);
                    const newMoney = srvData ? srvData.reduce((s, i) => s + i.total, 0) : 0;
                    await supabase.from('orders').update({ service_money: newMoney }).eq('id', order.id);
                    setLoading(false);
                    onClose();
                  }
                }} className="py-4 bg-[#D32F2F] hover:bg-[#B71C1C] text-white rounded-xl font-bold">➖ Xóa món</button>
                
                <button onClick={async () => {
                  if (!isActive) return alert("Phòng chưa có khách!");
                  const { data } = await supabase.from('room_combos').select('*').eq('room_type_id', room.room_type_id);
                  let list = data.map(c => `ID: ${c.id} | ${c.name} (${c.hours}h${c.minutes}m) - ${c.price}đ`).join('\n');
                  const addId = window.prompt(`Danh sách Combo phụ:\n${list}\n\nNhập ID Combo muốn MUA THÊM:` + "\n(Hệ thống tự động cộng dồn giờ và tiền)");
                  if (addId) {
                    const c = data.find(x => x.id == addId);
                    if (c) {
                      setLoading(true);
                      const addedMins = (c.hours * 60) + c.minutes;
                      const newMins = parseInt(order.extra_minutes || 0) + addedMins;
                      const newMoney = parseInt(order.extra_money || 0) + c.price;
                      
                      const oldExp = new Date(order.expected_checkout_time);
                      oldExp.setMinutes(oldExp.getMinutes() + addedMins);
                      const offset = oldExp.getTimezoneOffset() * 60000;
                      const newExpStr = (new Date(oldExp - offset)).toISOString().slice(0, 19).replace('T', ' ');

                      await supabase.from('orders').update({
                        extra_minutes: newMins, extra_money: newMoney, 
                        room_money: parseInt(order.combo_price || 0) + newMoney,
                        expected_checkout_time: newExpStr
                      }).eq('id', order.id);
                      setLoading(false);
                      onClose();
                    }
                  }
                }} className="py-4 bg-[#1976D2] hover:bg-[#0D47A1] text-white rounded-xl font-bold">➕ Mua combo phụ</button>

                <button onClick={async () => {
                  if (!isActive) return alert("Phòng chưa có khách!");
                  const { data } = await supabase.from('room_combos').select('*').eq('room_type_id', room.room_type_id);
                  let list = data.map(c => `ID: ${c.id} | ${c.name} - ${c.price}đ`).join('\n');
                  const editId = window.prompt(`Đang dùng: ${order.combo_name}\n\nDanh sách Combo:\n${list}\n\nNhập ID Combo CHÍNH muốn ĐỔI MỚI:`);
                  if (editId) {
                    const c = data.find(x => x.id == editId);
                    if (c) {
                      setLoading(true);
                      const checkinDt = new Date(order.checkin_time);
                      checkinDt.setHours(checkinDt.getHours() + c.hours);
                      checkinDt.setMinutes(checkinDt.getMinutes() + c.minutes + parseInt(order.extra_minutes || 0));
                      const offset = checkinDt.getTimezoneOffset() * 60000;
                      const newExpStr = (new Date(checkinDt - offset)).toISOString().slice(0, 19).replace('T', ' ');

                      await supabase.from('orders').update({
                        combo_id: c.id, combo_name: c.name, combo_hours: c.hours, combo_minutes: c.minutes, combo_price: c.price,
                        room_money: c.price + parseInt(order.extra_money || 0), expected_checkout_time: newExpStr
                      }).eq('id', order.id);
                      setLoading(false);
                      onClose();
                    }
                  }
                }} className="py-4 bg-[#0288D1] hover:bg-[#01579B] text-white rounded-xl font-bold">✏️ Sửa combo chính</button>

                <button onClick={async () => {
                  if (!isActive) return alert("Phòng chưa có khách!");
                  if (!order.extra_money || order.extra_money == 0) return alert("Chưa mua combo phụ nào!");
                  const { data } = await supabase.from('room_combos').select('*').eq('room_type_id', room.room_type_id);
                  let list = data.map(c => `ID: ${c.id} | ${c.name} (+${c.hours}h${c.minutes}m)`).join('\n');
                  const rmId = window.prompt(`Đã gia hạn thêm: ${order.extra_money}đ\n\nNhập ID Combo phụ muốn TRỪ ĐI:\n${list}`);
                  if (rmId) {
                    const c = data.find(x => x.id == rmId);
                    if (c) {
                      const deductMins = (c.hours * 60) + c.minutes;
                      if (deductMins > order.extra_minutes || c.price > order.extra_money) return alert("Trừ lố số lượng khách đã mua!");
                      setLoading(true);
                      const newMins = parseInt(order.extra_minutes) - deductMins;
                      const newMoney = parseInt(order.extra_money) - c.price;
                      
                      const oldExp = new Date(order.expected_checkout_time);
                      oldExp.setMinutes(oldExp.getMinutes() - deductMins);
                      const offset = oldExp.getTimezoneOffset() * 60000;
                      const newExpStr = (new Date(oldExp - offset)).toISOString().slice(0, 19).replace('T', ' ');

                      await supabase.from('orders').update({
                        extra_minutes: newMins, extra_money: newMoney, 
                        room_money: parseInt(order.combo_price || 0) + newMoney,
                        expected_checkout_time: newExpStr
                      }).eq('id', order.id);
                      setLoading(false);
                      onClose();
                    }
                  }
                }} className="py-4 bg-[#7B1FA2] hover:bg-[#4A148C] text-white rounded-xl font-bold">🗑️ Xóa combo phụ</button>
                
                <button onClick={async () => {
                  if (!isActive) return alert("Phòng chưa có khách!");
                  const val = window.prompt(`Tiền phòng & Dịch vụ đã cố định.\n\nNhập số tiền:\n- Số DƯƠNG (VD: 50000) để PHỤ THU\n- Số ÂM (VD: -20000) để GIẢM GIÁ`, order.adjustment_money || "0");
                  if (val !== null && !isNaN(val)) {
                    setLoading(true);
                    await supabase.from('orders').update({ adjustment_money: parseInt(val) }).eq('id', order.id);
                    setLoading(false);
                    onClose();
                  }
                }} className="py-4 bg-[#00796B] hover:bg-[#004D40] text-white rounded-xl font-bold">💸 Tăng / giảm giá</button>

                <button onClick={async () => {
                  if (!isActive) return alert("Phòng chưa có khách!");
                  const { data: emptyRooms } = await supabase.from('rooms').select('*').eq('branch_id', room.branch_id).eq('status', 'TRỐNG');
                  if (!emptyRooms || emptyRooms.length === 0) return alert("Hết phòng trống!");
                  const list = emptyRooms.map(r => `ID: ${r.id} | ${r.name}`).join('\n');
                  const targetId = window.prompt(`Danh sách phòng TRỐNG:\n${list}\n\nNhập ID phòng muốn CHUYỂN KHÁCH sang:`);
                  if (targetId && emptyRooms.find(r => r.id == targetId)) {
                    setLoading(true);
                    await supabase.from('orders').update({ room_id: targetId }).eq('id', order.id);
                    await supabase.from('rooms').update({ status: 'TRỐNG' }).eq('id', room.id);
                    await supabase.from('rooms').update({ status: 'ĐANG THUÊ' }).eq('id', targetId);
                    setLoading(false);
                    onClose();
                  }
                }} className="py-4 bg-[#455A64] hover:bg-[#263238] text-white rounded-xl font-bold">🔄 Chuyển phòng</button>

                <button onClick={async () => {
                  if (isActive) return alert("Phòng đang có khách, không thể đổi trạng thái!");
                  setLoading(true);
                  const newStatus = room.status === 'DỌN PHÒNG' ? 'TRỐNG' : 'DỌN PHÒNG';
                  await supabase.from('rooms').update({ status: newStatus }).eq('id', room.id);
                  setLoading(false);
                  onClose();
                }} className="py-4 bg-[#E6A822] hover:bg-[#C59017] text-white rounded-xl font-bold">🧹 Đổi Dọn/Trống</button>
                
                <button onClick={async () => {
                  if (!isActive) return alert("Phòng chưa có khách!");
                  const newTime = window.prompt(`Nhập lại giờ Check-in mới:\n(Năm-Tháng-Ngày Giờ:Phút:Giây)`, order.checkin_time);
                  if (newTime) {
                    setLoading(true);
                    const oldIn = new Date(order.checkin_time).getTime();
                    const oldOut = new Date(order.expected_checkout_time).getTime();
                    const duration = oldOut - oldIn;
                    
                    const newInDt = new Date(newTime);
                    const newOutDt = new Date(newInDt.getTime() + duration);
                    
                    const offset = newInDt.getTimezoneOffset() * 60000;
                    const inStr = (new Date(newInDt - offset)).toISOString().slice(0, 19).replace('T', ' ');
                    const outStr = (new Date(newOutDt - offset)).toISOString().slice(0, 19).replace('T', ' ');

                    await supabase.from('orders').update({ checkin_time: inStr, expected_checkout_time: outStr }).eq('id', order.id);
                    setLoading(false);
                    onClose();
                  }
                }} className="py-4 bg-[#5D4037] hover:bg-[#3E2723] text-white rounded-xl font-bold">✏️ Sửa Check-in</button>
                
                <button onClick={handleOpenCheckout} className="py-4 col-span-2 bg-[#C62828] hover:bg-[#B71C1C] text-white rounded-xl font-bold text-lg shadow-lg">💳 TRẢ PHÒNG & THANH TOÁN</button>
              </div>
            </>
          )}

          {/* ================= GÓC NHÌN 2: THÊM DỊCH VỤ ================= */}
          {view === "service" && (
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-[#F57C00] mb-4">🍔 Gọi Menu Dịch Vụ</h3>
              <select className="w-full px-4 py-3 rounded-xl border border-gray-300 font-medium"
                onChange={(e) => setSelectedService(services.find(s => s.id == e.target.value))}>
                {services.map(s => <option key={s.id} value={s.id}>{s.name} - {money(s.price)}</option>)}
              </select>
              <label className="block text-sm font-bold text-gray-700">Số lượng</label>
              <input type="number" min="1" value={quantity} onChange={(e) => setQuantity(parseInt(e.target.value)||1)} className="w-full px-4 py-3 rounded-xl border border-gray-300 font-bold text-lg" />
              <div className="flex space-x-3 mt-8">
                <button onClick={() => setView("menu")} className="flex-1 py-3 bg-gray-200 text-gray-800 font-bold rounded-xl">❌ Quay lại</button>
                <button onClick={handleServiceSubmit} disabled={loading} className="flex-1 py-3 bg-[#F57C00] hover:bg-[#E65100] text-white font-bold rounded-xl">✅ THÊM MÓN</button>
              </div>
            </div>
          )}

          {/* ================= GÓC NHÌN 3: TRẢ PHÒNG ================= */}
          {view === "checkout" && (
            <div className="space-y-4">
              <h3 className="text-2xl font-bold text-[#C62828] mb-4 text-center">💳 TỔNG KẾT HÓA ĐƠN</h3>
              
              <div className="bg-[#F4FFF7] p-4 rounded-xl border border-[#B7E4C7] space-y-2 text-[#18392B] font-medium">
                <div className="flex justify-between"><p>Tiền phòng (Combo + Gia hạn):</p><p className="font-bold">{money(checkoutData.roomMoney)}</p></div>
                <div className="flex justify-between"><p>Tiền dịch vụ (Ăn uống):</p><p className="font-bold">{money(checkoutData.serviceMoney)}</p></div>
                <div className="flex justify-between"><p>Phụ thu / Giảm giá (Trong ca):</p><p className="font-bold">{money(checkoutData.adjustMoney)}</p></div>
                <hr className="border-[#B7E4C7] my-2"/>
                <div className="flex justify-between text-xl text-red-600 font-bold"><p>TỔNG CẦN THU:</p><p>{money(checkoutData.total)}</p></div>
              </div>

              <div>
                <label className="block text-sm font-bold text-red-600 mb-1 mt-4">Giờ khách ra & Ghi nhận doanh thu (HH:MM)</label>
                <input type="time" value={checkoutTime} onChange={(e) => setCheckoutTime(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-gray-300 font-bold text-lg text-center" />
              </div>

              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">💵 Tiền mặt khách đưa</label>
                  <input type="text" value={money(cashAmount)} onChange={(e) => handleMoneyType('cash', e.target.value)} className="w-full px-4 py-3 rounded-xl border border-gray-300 font-bold text-lg" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">🏦 Chuyển khoản khách gửi</label>
                  <input type="text" value={money(transferAmount)} onChange={(e) => handleMoneyType('transfer', e.target.value)} className="w-full px-4 py-3 rounded-xl border border-gray-300 font-bold text-lg" />
                </div>
              </div>

              <div className="flex space-x-3 mt-8 pt-4 border-t border-gray-200">
                <button onClick={() => setView("menu")} className="flex-1 py-4 bg-gray-200 text-gray-800 font-bold rounded-xl text-lg">❌ Hủy bỏ</button>
                <button onClick={handleCheckoutSubmit} disabled={loading} className="flex-[2] py-4 bg-[#C62828] hover:bg-[#B71C1C] text-white font-bold rounded-xl text-lg shadow-lg">
                  {loading ? "⏳ Đang xử lý..." : "✅ CHỐT THANH TOÁN"}
                </button>
              </div>
            </div>
          )}

          {/* Góc nhìn checkin vẫn giữ nguyên logic đã làm trước đó */}
          {view === "checkin" && (
             <div className="space-y-4">
             <h3 className="text-xl font-bold text-[#2D6A4F] mb-4">🛏️ Điền thông tin Nhận phòng</h3>
             <div className="grid grid-cols-2 gap-4">
               <div>
                 <label className="block text-sm font-bold text-gray-700 mb-1">Tên/SĐT Khách hàng</label>
                 <input type="text" value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Khách vãng lai..." className="w-full px-4 py-3 rounded-xl border border-gray-300 outline-none" />
               </div>
               <div>
                 <label className="block text-sm font-bold text-gray-700 mb-1">Giờ vào thực tế (HH:MM)</label>
                 <input type="time" value={checkinTime} onChange={(e) => setCheckinTime(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-gray-300 font-bold outline-none" />
               </div>
             </div>
             <div>
               <label className="block text-sm font-bold text-gray-700 mb-1 mt-2">Chọn Combo Giá Phòng</label>
               {loading ? <p>Đang tải...</p> : (
                 <select className="w-full px-4 py-3 rounded-xl border border-gray-300 font-medium outline-none" onChange={(e) => setSelectedCombo(combos.find(c => c.id == e.target.value))}>
                   {combos.map(c => <option key={c.id} value={c.id}>{c.name} - {c.hours}h{c.minutes}m - {money(c.price)}</option>)}
                 </select>
               )}
             </div>
             <div className="flex space-x-3 mt-8 pt-4 border-t border-gray-200">
               <button onClick={() => setView("menu")} className="flex-1 py-3 bg-gray-200 font-bold rounded-xl">❌ Quay lại</button>
               <button onClick={handleCheckinSubmit} disabled={loading} className="flex-1 py-3 bg-[#2D6A4F] hover:bg-[#18392B] text-white font-bold rounded-xl">✅ XÁC NHẬN</button>
             </div>
           </div>
          )}
        </div>
      </div>
    </div>
  );
}